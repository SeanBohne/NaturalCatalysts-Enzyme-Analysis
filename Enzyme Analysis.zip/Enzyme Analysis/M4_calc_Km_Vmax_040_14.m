function [Vmax, Km] = M4_calc_Km_Vmax_040_14(substrate_conc, v0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description 
% This function calculates Km and Vmax based on the given inputs
%
% Function Call
% [Vmax, Km] = M4_calc_Km_Vmax_040_14(substrate_conc, v0)
%
% Input Arguments
% substrate_conc - initial substrate concentration data
% v0 - v0 data
%
% Output Arguments
% Vmax - Vmax value
% Km - Km value
%
% Assignment Information
%   Assignment:     M2, Problem Vmax_Km
%   Team member:    Sean Bohne, bohne@purdue.edu
%   Team ID:        040-14
%   Academic Integrity:
%     [] We worked with one or more peers but our collaboration
%        maintained academic integrity.
%     Peers we worked with:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ____________________
%% INITIALIZATION

% counting variable
i = 1;

%% ____________________
%% CALCULATIONS

% linearize v0 data
% v0_linear = 1 ./ v0; % changed linearized data for the Eadie-Hofstee
% model
v0_linear = v0; % Improvement 2 - changed linearized y data for the 
% Eadie-Hofstee model

% linearize substrate data
% substrate_linear = 1 ./ substrate_conc; % changed linearized data for the
% Eadie-Hofstee model
substrate_linear = v0 ./ substrate_conc; % Improvement 2 - changed 
% linearized x data for the Eadie-Hofstee model

while i <= length(v0(1, :)) / 10
    % determines which indices to use
    index1 = 10 * i - 9;
    index2 = 10 * i;
    
    % changes v0 data used for each iteration
    v0_lin = v0_linear(1, index1:index2);

    % changes substrate data used for each iteration
    sub_lin = substrate_linear(1, index1:index2);

    % calculate slope and y intercept of the linear model
    coeffs = polyfit(sub_lin, v0_lin, 1);

    % assign the slope to m
    m = coeffs(1);

    % assign the y intercept to b
    b = coeffs(2);

    % calculate Vmax
    % Vmax(i) = 1 / b; % changes Vmax calculation for the Eadie-Hofstee
    % model
    Vmax(i) = b; % changes Vmax calculation based on the Eadie-Hofstee model

    % calculate Km
    % Km(i) = m * Vmax(i); % changes Km calculation for the Eadie-Hofstee
    % model
    Km(i) = -m; % changes Km calculation based on the Eadie-Hofstee model

    % updates counting variable
    i = i + 1;
end

%% ____________________
%% FORMATTED TEXT/FIGURE DISPLAYS


%% ____________________
%% RESULTS


%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% We have not used source code obtained from any other unauthorized
% source, either modified or unmodified. Neither have we provided
% access to my code to another. The program we are submitting
% is our own original work.

