function [] = M4_main_040_14()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description 
% The main function gathers the data provided by the subfunctions and
% displays the various results and figures
%
% Function Call
% [] = M4_main_040_14()
%
% Input Arguments
%
% Output Arguments
%
% Assignment Information
%   Assignment:     M4, Problem Main
%   Team member:    Sean Bohne, bohne@purdue.edu, Saketh Gopu,
%                   gopu@purdue.edu, Michael Meiners, Meiners@purdue.edu,
%                   Mayank Agarwal, agarw316@purdue.edu
%   Team ID:        040-14
%   Academic Integrity:
%     [] We worked with one or more peers but our collaboration
%        maintained academic integrity.
%     Peers we worked with:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ____________________
%% INITIALIZATION

% enzyme data
data = readmatrix("Data_nextGen_KEtesting_allresults.csv");

% product concentration data
prod_data = data(5:end, 2:end);

% substrate concentration data
subs_data = data(3, 2:end);

% v0 values
v0 = M4_v0_calculation_040_14(prod_data);

% Vmax and Km algorithm values
[Vmax, Km] = M4_calc_Km_Vmax_040_14(subs_data, v0);

% plots the data and models
M4_graph_040_14(Km, Vmax, v0);

%% ____________________
%% CALCULATIONS


%% ____________________
%% FORMATTED TEXT/FIGURE DISPLAYS


%% ____________________
%% RESULTS


%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% We have not used source code obtained from any other unauthorized
% source, either modified or unmodified. Neither have we provided
% access to my code to another. The program we are submitting
% is our own original work.

