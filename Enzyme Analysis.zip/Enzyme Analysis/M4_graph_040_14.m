function [] = M4_graph_040_14(Km, Vmax, v0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description 
% Takes the calculated values from the other sub functions and plots the
% needed data that was asked for in the problem. 
%
% Function Call
% [] = M4_graph_040_14(Km, Vmax, v0)
%
% Input Arguments
% Km - substrate concentration at 1/2 Vmax
% Vmax - maximum reaction velocity
% v0 - initial reaction velocity
%
% Output Arguments
%
% Assignment Information
%   Assignment:     M4, Problem graph
%   Team member:    Michael, Meiners@purdue.edu [repeat for each person]
%   Team ID:        040-14
%   Academic Integrity:
%     [] We worked with one or more peers but our collaboration
%        maintained academic integrity.
%     Peers we worked with: Name, login@purdue [repeat for each]
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ____________________
%% INITIALIZATION
% makes given data usable
data = readmatrix("Data_nextGen_KEtesting_allresults.csv");
% defines given data to variables
ProductCon = data(5:end,2:end);
substrateCon = data(3, 2:end);
%set variable array used for calculations
timev0 = 0:500;

%% ____________________
%% CALCULATIONS

for j = 1:10 % used to plot 10 diffrent figures
    Pindex1 = 10 * j - 9; % Used for the index range
    Pindex2 = 10 * j;
    figure(j)
    for k = 1:10 % plots 10 subplots per figure
        range = Pindex1:Pindex2;  % range per data set
        % created the plottable data
        time = 0:length(ProductCon(:,range(k))) - 1;
        v0i = v0(k) * timev0;
        % labels the graph for techinical presentation
        sgtitle("Product concentration over time at varying" + ...
            " initial substrate concentration");
        % subplots in the correct location
        subplot(3,4,k)
        plot(time, ProductCon(:,range(k)), "b", timev0, v0i, "r--")
        % Formating for technical presentation
        xlabel("Time [T](s)", "FontSize", 5);
        ylabel("Product Concentration [" + ...
            "P](µM)", "FontSize", 5)
        title("Test #"+ num2str(k) +" Product Concentration Over Time", ...
            "FontSize", 5);
        legend("Product Concentration", "Initial Velocity", ...
            "Location","best", "FontSize", 3);
        grid on; 
    end
end

for i = 1:10
    % indicates which figure to plot
    figure_num = 10 + i;
    % Used for the index range
    Pindex1 = 10 * j - 9;
    Pindex2 = 10 * j;

    figure(11)
    % calculates the v model for the Michaelis plot
    v_model = (Vmax(i) * substrateCon(Pindex1:Pindex2)) ./ (Km(i) + ...
        substrateCon(Pindex1:Pindex2));
    % formats the extra graph for technical presentation
    subplot(3,4,i)
    plot(substrateCon(Pindex1:Pindex2), v_model)
    xlabel("Subtstrate Concentration [S](µM)", "FontSize", 5)
    ylabel("Reaction Velocity (µM/s)", "FontSize", 5)
    title("Test #" + num2str(i) + " Michaelis-Menten Plot", "FontSize", 5)
    sgtitle("Enzyme Test Data Michaelis-Menten Plots", "FontSize", 12)
    grid on;
end

%% ____________________
%% FORMATTED TEXT/FIGURE DISPLAYS
% all figure displays are in the calculated section as this whole
% sub-function is for graphing specifically

%% ____________________
%% RESULTS


%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% We have not used source code obtained from any other unauthorized
% source, either modified or unmodified. Neither have we provided
% access to my code to another. The program we are submitting
% is our own original work.


