function [v0] = M4_v0_calculation_040_14(prod_data)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description: The program is used to calculate the value of the
% v0_i, which is the initial velocity parameter. 
% 
% Function Call
% [v0] = M4_v0_calculation_040_14(prod_data)
%
% Input Arguments
% prod_data - input product concentration data
%
% Output Arguments
% v0 - v0_i array
%
% Assignment Information
%   Assignment:     M4, Problem v0
%   Team member:    Mayank Agarwal, agarw316@purdue.edu
%   Team ID:        040-14
%   Academic Integrity:
%     [] We worked with one or more peers but our collaboration
%        maintained academic integrity.
%     Peers we worked with:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ____________________
%% INITIALIZATION

% counting variable
j = 1;

count = 1:50; % Improvement 1 - moved count to initialization and changed
% to 1:50 instead of 1:10 to use a larger number of product concentration
% values for increased accuracy

%% ____________________
%% CALCULATIONS

% calculates v0's for each test and error analysis
while j <= length(prod_data(1, :)) / 10
  index1 = 10 * j - 10; % first index for each iteration

  for i = 1:10
    value = rmmissing(prod_data(count, index1 + i)');
    % count = 1:10; % count moved to initialization and changed to 1:50
    slope_calc = polyfit(count, value, 1);
    v0(index1 + i) = slope_calc(1);
    product_con = slope_calc(1) * count + slope_calc(2);
    SSE = sum((value - product_con) .^ 2);
    SST = sum((value - mean(value)) .^ 2);
    r_squared(index1 + i) = 1 - SSE/SST;
  end

  % increase counting variable
  j = j + 1;
end


%% ____________________
%% FORMATTED TEXT/FIGURE DISPLAYS

fprintf("R^2 values for each v0 calculation in order of increasing initial" + ...
    " substrate concentration and test number:\n")

j = 1;

while j <= length(prod_data(1, :)) / 10
    index1 = 10 * j - 9;
    fprintf("Test %d:\n", j)
    for k = 1:10        
        fprintf("Initial substrate concentration number %d: ", k)
        fprintf("%d\n", r_squared(index1 + k - 1))
    end

    j = j + 1;
end

%% ____________________
%% RESULTS


%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% We have not used source code obtained from any other unauthorized
% source, either modified or unmodified. Neither have we provided
% access to my code to another. The program we are submitting
% is our own original work.
